
### Usage guide

* Grab the hid_listener [here](https://www.pjrc.com/teensy/hid_listen.html)
* Put it in the rule_usage folder
  * You can copy that folder to wherever you want
* Start collecting data with [logger](run_logger.pyw)
* After you collected some data - handle it via running [collect_data](collect_data.py)
